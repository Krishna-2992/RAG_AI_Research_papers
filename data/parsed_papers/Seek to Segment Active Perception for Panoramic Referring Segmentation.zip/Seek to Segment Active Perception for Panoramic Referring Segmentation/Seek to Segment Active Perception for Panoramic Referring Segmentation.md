## Seek to Segment: Active Perception for Panoramic Referring Segmentation

Song Tang , Shuming Hu , Xincheng Shuai , Henghui Ding , Yu-Gang Jiang

Fudan University, China

Existing referring segmentation models passively process static images captured from fixed perspectives, limiting their applicability in Embodied AI, where agents must perform active perception in the continuous 360 ◦ environments. To bridge this gap, we introduce a novel task: ActivePanoramicReferring Segmentation (APRS) . In this setting, an agent is required to adjust its viewing direction ( ∆ θ, ∆ ϕ ) to explore the 360 ◦ environment, seeking the object specified by a user instruction for segmentation. To tackle this challenging task, we propose PanoSeeker , a memory-augmented agent for efficient APRS. Rather than relying on heuristic scanning, PanoSeeker integrates a Vision-Language Model (VLM) with EgoSphere -an explicit spatial visual memory. By progressively integrating sequential local observations into a unified 360 ◦ representation, EgoSphere enables the agent to plan efficient and nonredundant search trajectories. Once the target is found, the agent performs active viewpoint alignment and outputs the segmentation mask. Furthermore, we curate an expert-annotated search trajectory dataset with memory timelines for Supervised Fine-Tuning, followed by Reinforcement Learning post-training to explicitly optimize PanoSeeker's exploration efficiency. Extensive experiments on our newly established APRS benchmark demonstrate that PanoSeeker achieves superior search efficiency and segmentation accuracy, significantly outperforming adapted state-of-the-art baselines.

Keywords: Agent Memory · Embodied AI · Vision-Language Agent · Active Perception · Referring Image Segmentation · Panoramic Vision

Website:

https://henghuiding.com/APRS/

Email:

henghui.ding@gmail.com

## 1 Introduction

Referring Segmentation [1-7] has achieved remarkable progress by segmenting target objects guided by natural language expressions. Powered by recent advancements in Vision-Language Models (VLMs) [8-11], contemporary referring segmentation models [12-19] demonstrate exceptional reasoning ability for precise pixellevel segmentation. However, these methods passively process static images captured from fixed perspectives, which significantly limits their deployment in real-world Embodied AI [20, 21], where agents must actively perceive their surroundings to find targets within continuous 360 ◦ environments.

Transitioning from passive fixed-view observation to active multi-view perception presents fundamental challenges. In 360 ◦ environments, identifying a target necessitates reasoning over complex cross-view spatial relationships (e.g., 'the floor cabinet opposite the bed') and performing active exploration. To address these challenges, we introduce a novel task: Active Panoramic Referring Segmentation (APRS) . In this setting, an agent is required to adjust its viewing direction ( ∆ θ, ∆ ϕ ) to explore the 360 ◦ environment, seeking the object specified by a user instruction for segmentation, as shown in Fig. 1.

However, applying existing perception methods to this task faces a dilemma. On the one hand, explicit 3D modeling (e.g., point clouds [22-28], or Gaussian Splatting [29-31]) resolves spatial queries by first reconstructing the entire 3D scene, which provides detailed spatial layouts but entails substantial computational and hardware costs. On the other hand, conventional 2D methods [32-34] that directly process flattened panoramic images introduce severe geometric distortions and wraparound boundaries, while those partitioning the 360 ◦ scene into an isolated sequence of perspective views sacrifice global spatial context.

<!-- image -->

Figure 1 Active Panoramic Referring Segmentation (APRS) requires an agent to search for and segment a target (e.g., finding the 'floor cabinet ') within a continuous 360 ◦ environment based on a user instruction. The bottom row illustrates a search trajectory: the agent adjusts its camera pose ( θ, ϕ ) to reason about spatial relations (e.g., 'opposite the bed') and search the target for segmentation.

<!-- image -->

To address this dilemma, we construct the APRSbenchmark , which leverages abundant and easily accessible panoramic images to simulate realistic 360 ◦ egocentric exploration scenes. It eliminates the need for resourceintensive 3D reconstructions while covering diverse indoor and outdoor environments. Moreover, this benchmark features four distinct types of spatial referring expressions (EGO, UNIQ, ALLO, and MULTIHOP) to comprehensively evaluate agents' cross-view spatial reasoning ability across various difficulties. We further provide comprehensive evaluation protocols for benchmarking.

Additionally, we propose PanoSeeker , a Vision-Language Agent designed for APRS. To reduce redundant exploration and maintain global spatial context, we design EgoSphere , an explicit spatial-visual memory, which integrates sequential local observations into a unified 360 ◦ equirectangular panorama (ERP) map. Augmented by EgoSphere, PanoSeeker can perform efficient searching. Once the target is found, the agent performs active viewpoint alignment and generates a segmentation mask. Furthermore, we curate an expert-annotated search trajectory dataset with memory timelines for Supervised Fine-Tuning (SFT). This is followed by Reinforcement Learning (RL) using GRPO [35], which incorporates efficiency and terminal rewards to explicitly optimize PanoSeeker's exploration efficiency. Our main contributions are summarized as follows:

- We introduce Active Panoramic Referring Segmentation ( APRS ), a novel task that requires an agent to actively explore 360 ◦ environments to seek and segment targets based on language instructions. To support this, we construct the APRS benchmark, which incorporates four distinct types of spatial referring expressions and comprehensive evaluation protocols.
- We propose PanoSeeker , a memory-augmented agent that leverages an explicit spatial visual memory

EgoSphere to facilitate efficient exploration.

- We contribute an expert-annotated search trajectory dataset with memory timelines for SFT. Additionally, we employ RL with efficiency and terminal rewards to explicitly optimize PanoSeeker's exploration efficiency.
- Extensive experiments demonstrate that PanoSeeker outperforms existing state-of-the-art baselines adapted for this task.

## 2 Related Work

Referring Image Segmentation. Referring Image Segmentation (RIS) [1, 3, 36] targets the segmentation of specific objects in an image according to a given textual description. Early approaches [37-40] rely on CNNs to obtain visual features and LSTMs to encode the linguistic expressions, and then combine the two modalities via concatenation or other straightforward fusion operations to form a joint representation. VLT [3, 6] is the first to bring the transformer into this task, recasting RIS as an attention problem in which language features serve as queries over the visual features and the segmentation result is obtained by decoding the transformer output. Liu et al. [4] further extend the task to Generalized Referring Expression Segmentation (GRES), which accounts for both multi-target and empty-target cases. More recently, Large Language Models (LLMs) and Vision Language Models (VLMs) [8, 41-44] have substantially advanced vision-language tasks through their strong common-sense reasoning ability, offering new opportunities for RIS. Along this line, LISA [12] introduces the [SEG] token, which allows the model to handle expressions that demand complex reasoning and common-sense knowledge. READ [14] treats similarity as reference points to direct where MLLMs should attend during interactive reasoning. Seg-Zero [45] adopts a purely reinforcement-learning scheme (GRPO [35]) to acquire the reasoning process from scratch, producing a reasoning chain prior to the final mask. VisionReasoner [15] presents a unified framework that addresses multiple visual perception tasks through reasoning within a single shared model. Unlike these methods, which depend on static images captured from a fixed viewpoint, our PanoSeeker is able to actively perceive the continuous 360 ◦ environment.

Agent Memory. Existing agent memory systems can be broadly categorized into flat-context and structured designs. MemGPT [46] and MemoryOS [47] adopt flat-context paradigms, which leverage paging or streaming mechanisms to extend memory capacity; however, their reliance on raw dialogue logs often introduces significant information redundancy and prohibitive retrieval overhead as histories expand. To enhance semantic coherence and navigability, MemoryBank [48] and A-Mem [49] adopt the structured design to organize memory into hierarchical or graph-based representations. More recently, frameworks such as xMemory [50] have refined these structures by tailoring hierarchical retrieval to the dynamic nature of agentic workloads. Extending beyond textual modalities, vision-centric frameworks like VisMem [51] incorporate short- and long-term latent visual memory into VLMs to enable robust long-term temporal reasoning. Despite these advancements, existing history-based methods face a critical scalability bottleneck, as context length and query latency scale sharply with interaction history. To address this, we propose EgoSphere, a spatial visual memory that maps sequential observations onto a fixed-resolution 360 ◦ panoramic canvas; this ensures a constant-length context regardless of the trajectory's length.

PanoramicVisionandEmbodiedReferring. Panoramic vision provides comprehensive 360 ◦ contextual understanding, significantly advancing the ability of intelligent systems in navigation [21, 52] and perception [33, 34, 53]. Early panoramic vision methods primarily focused on static images or videos with a 360 ◦ Field-of-View (FoV), addressing challenges such as geometric distortion [54-56], representation learning [53, 57-59], and multi-modal integration [33, 34, 60, 61]. However, relying on static, fully observable panoramas diminishes the inherent need for active exploration and spatial reasoning. To address these limitations, recent embodied tasks (e.g., Refer360 [52], REVERIE [21]) integrate linguistic instructions into panoramic environments to inspire models' active perception and spatial reasoning ability. But they remain limited: Refer360 [52] relies on dense, step-by-step instructions that reduce the task to low-level instruction following, while REVERIE [21] provides multi-view observations at each step, turning search into a passive selection task. In contrast, our proposed Active Panoramic Referring Segmentation (APRS) requires the agent to adjust its viewing direction to explore the continuous 360 ◦ environment, seeking the object specified by a user instruction for segmentation, thereby truly demonstrating the model's ability for active perception and spatial reasoning.

## 3 The APRS Task and Benchmark

In this section, we formally define the Active Panoramic Referring Segmentation (APRS) task and describe the construction of our benchmark, including the dataset, environment setup, and evaluation protocols.

## 3.1 Task Formulation

Active Panoramic Referring Segmentation (APRS) requires an agent to search for and segment a target within a continuous 360 ◦ environment E based on a language instruction I . Starting from an initial orientation ( θ 0 , ϕ 0 ) with a constrained Field of View (FoV), the agent iteratively updates its viewpoint ( θ t , ϕ t ) to explore the environment. At each step t , the agent perceives a visual observation V t = Proj ( E,θ t , ϕ t , ψ ) via a perspective projection Proj ( · ) with an FoV ψ . Given I , the agent F maintains a memory state M t and predicts an action a t :

<!-- formula-not-decoded -->

where M t +1 encapsulates the exploration history updated by the current observation V t . The action space includes relative movements a t = (∆ θ t , ∆ ϕ t ) , denoting the direction of the viewpoint shift, and a termination signal that invokes the prediction of the segmentation mask S once the target is found.

## 3.2 Environment and Dataset Construction

Unlike traditional Referring Image Segmentation (RIS) [1, 6], which assumes the target is always within the initial view, the APRS task necessitates active exploration to handle targets that are initially out of sight. To this end, we construct a large-scale benchmark encompassing diverse indoor and outdoor scenes, complemented by complex referring expressions requiring spatial reasoning ability.

Data Sources and Panoramic Simulation. We collect high-resolution panoramas from 360-Indoor [62], PANDORA [63], and SUN360 [64], resulting in 4,971 unique scenes. This scale substantially surpasses existing language-guided 3D benchmarks such as ScanRefer [65] (comprising ∼ 800 indoor scenes) and offers greater diversity, spanning both indoor and outdoor environments.

To simulate a continuous 360 ◦ environment, we employ gnomonic projection to extract local perspective views from equirectangular panoramas (ERPs). Given an orientation ( θ, ϕ ) and a Field of View (FoV) ψ = ( ψ h , ψ v ) , we generate rectilinear views by back-projecting perspective coordinates onto a unit sphere and subsequently sampling from the ERP. In our implementation, we set the horizontal FoV to ψ h = 120 ◦ and the vertical FoV to ψ v = 90 ◦ , aligning with consumer-grade depth cameras. More details are provided in the Appendix.

Human-in-the-Loop Annotation Pipeline. We develop a multi-stage annotation pipeline that combines human expertise with foundation models [66, 67]. First, professional annotators annotate salient targets using bounding boxes. To encourage active exploration, initial camera orientations are directed away from the target, ensuring the target is initially out of the agent's view. Next, based on the spatial relationships between the initial camera orientation, the target, and other anchor objects, annotators are required to construct trajectory-centric spatial referring expressions. These expressions incorporate spatial relations, object attributes, and egocentric cues to guide the agent toward the target. To achieve pixel-level segmentation, we leverage SAM-3 [67] to generate initial masks, followed by manual refinement. Additionally, we employ VLMs (e.g., GPT-5.2 [66]) for semantic cross-checking to ensure the high reliability of our dataset.

Taxonomy of Spatial Referring Expressions. To evaluate diverse spatial reasoning ability, we categorize the spatial referring expressions into four types based on their linguistic and spatial complexity, as shown in Table 1:

- Egocentric (EGO) : These instructions specify the target's location relative to the agent's current orientation. The primary challenge lies in mapping linguistic directional cues to precise spatial actions to effectively locate the target. (e.g., 'Turn right to find the sofa.' )
- Unique-Attribute (UNIQ) : These instructions identify targets based on distinctive visual attributes (e.g., color or shape) to distinguish them from other objects of the same category within the 360 ◦ scene. The core

Table 1 Taxonomy of Spatial Referring Expressions in the APRS Benchmark. O is the target object; { A } denotes visual attributes; R represents spatial relations; v is the initial camera viewpoint; and O anc is the anchor object.

| Category   | Formal Definition          | Description                                         | Number(%)     |
|------------|----------------------------|-----------------------------------------------------|---------------|
| EGO        | find ( O, { A } ,R,v )     | Relations relative to the initial camera viewpoint  | 1,365 (18.4%) |
| UNIQ       | find ( O, { A } )          | Objects with unique visual attributes (e.g., color) | 3,213 (43.3%) |
| ALLO       | find ( O, { A } ,R,O anc ) | Relations relative to an external anchor object     | 2,389 (32.2%) |
| MULTIHOP   | EGO ◦ ALLO                 | Multi-step reasoning via viewpoint and spatial cues | 453 (6.1%)    |

challenge involves fine-grained recognition and grounding of the specified instances across a panoramic view. (e.g., 'The yellow floor lamp in the room.' )

- Allocentric (ALLO) : These expressions define the target's position relative to other anchor objects in the 360 ◦ environment. The agent must interpret object-to-object spatial relationships to identify the correct target among potential distractors. (e.g., 'The chair opposite the sofa.' )
- Multi-hop (MULTIHOP) : These instructions require complex reasoning by integrating both viewpoint adjustments and relative spatial cues. As the most challenging category, they demand sequential decomposition and multi-step reasoning. (e.g., 'Turn around and find the chair next to the table.' )

Supervised Fine-Tuning (SFT) Dataset Construction. Different from the initial APRS dataset annotation Phase, we recruit new annotators to generate exploration trajectories for fine-tuning the agent model. Given an instruction I and an initial camera orientation, annotators are required to find the target by adjusting the FoV based on camera pose parameters ( θ, ϕ ). We discretize the horizontal ∆ θ and vertical ∆ ϕ action space into multiples of 30 ◦ . Horizontal actions include Small ( 30 ◦ ), Medium ( 60 ◦ ), Large ( 120 ◦ ), and U-turn ( 180 ◦ ); Vertical actions consist of Small ( 30 ◦ ), Medium ( 60 ◦ ), and Large ( 90 ◦ ), facilitating a range from fine alignment to complete FoV shifts. At each step, spatial coordinates ( θ t , ϕ t ) , visual observations V t , and a memory M t (detailed later in section 4.1) are recorded. Trajectories exceeding the step limit or deviating significantly from the target are discarded and reassigned to different annotators.

Dataset Statistics. The APRS dataset comprises 7,420 samples across 4,971 scenes, split into training and testing sets at a 7:3 ratio. On average, each scene contains 1.5 instructions spanning four difficulty levels: EGO, UNIQ, ALLO, and MULTIHOP. The average expression length is 7.38 words. These instructions incorporate diverse spatial prepositions (e.g., 'opposite' , 'behind' , and 'adjacent to' ), necessitating spatial reasoning and active perception ability to search for and segment targets in the continuous 360 ◦ environments.

## 3.3 Evaluation Metrics

To comprehensively evaluate the performance of the APRS agent, we establish a multi-dimensional evaluation protocol comprising three dimensions: (i) task success, (ii) exploration efficiency, and (iii) segmentation quality.

- Task Success. We define the Success Rate (SR) to measure the agent's ability to search for and segment the referred target. An episode is considered successful if: (1) the search process terminates at step T ; (2) the final viewpoint direction ( θ T , ϕ T ) is within a geodesic distance threshold τ (calculated using the great-circle distance) from the target's ground-truth centroid ( θ ∗ , ϕ ∗ ) ; and (3) the predicted mask S achieves an IoU ≥ 0 . 5 . Formally:

<!-- formula-not-decoded -->

where N is the total number of episodes and I ( · ) is the indicator function. For each episode, the geodesic distance is defined as:

<!-- formula-not-decoded -->

Figure 2 Overview of the PanoSeeker framework. PanoSeeker integrates a VLM with EgoSphere memory to predict movements (∆ θ t , ∆ ϕ t ) from inputs ( V t , I, M t ) . Subsequently, an Active Alignment and Segmentation module generates the mask S . Exploration efficiency is guided by efficiency ( R eff ) and terminal ( R term ) rewards. Bottom: visualization of a search trajectory and its associated memory accumulation.

<!-- image -->

- Exploration Efficiency. Efficiency is crucial for active agents. We report the Average Steps (AS) , which represents the mean number of action steps taken before termination across successful episodes. Furthermore, we adapt Success weighted by Path Length (SPL) to the panoramic setting:

<!-- formula-not-decoded -->

where S i is the binary success indicator from the SR metric. L i represents the shortest geodesic distance from the initial orientation ( θ 0 , ϕ 0 ) to the target's ground-truth centroid ( θ ∗ , ϕ ∗ ) , and P i is the cumulative great-circle distance traversed by the agent, defined as P i = ∑ T t =1 dist { ( θ t , ϕ t ) , ( θ t -1 , ϕ t -1 ) } .

- Segmentation Quality. Following standard Referring Image Segmentation benchmarks [1, 3, 6], we evaluate the performance using meanIntersection over Union (mIoU) . For episodes where SR = 0 , the IoU is set to 0.

## 4 Method

We present PanoSeeker , a Vision-Language Agent integrated with a spatial visual memory EgoSphere , specifically designed for the APRS task. To ensure non-redundant active search and spatial reasoning, PanoSeeker is first trained on an expert-annotated trajectory dataset via Supervised Fine-Tuning (SFT), followed by Reinforcement Learning (RL) to explicitly optimize exploration efficiency. Once the target is found, an Active Alignment and Segmentation module is employed for final viewpoint refinement and pixel-level segmentation.

## 4.1 EgoSphere: Spatial Visual Memory

A primary challenge in APRS is maintaining global spatial consistency under a constrained FoV. Existing memory methods often rely on textual logs or isolated perspective crops-which fail to capture the geometric continuity of a 360 ◦ environment and lack trajectory history, leading to redundant exploration (i.e., dead loops). To bridge this gap, we introduce EgoSphere , an explicit memory which progressively maps sequential local observations into a geometrically consistent, annotated 360 ◦ exploration map to ensure targeted, non-redundant search.

Progressive Canvas Construction. We instantiate the spatial memory as an Equirectangular Panorama (ERP) canvas M ∈ R H × W × 3 , initialized as a zero-valued tensor. At each step t , the agent receives a perspective FoV V t at orientation ( θ t , ϕ t ) . To integrate this local observation, we back-project V t onto a unit sphere and map it to the ERP coordinates:

<!-- formula-not-decoded -->

where Proj -1 ( · ) denotes the inverse gnomonic projection and ⊕ signifies the pixel-wise update. This formulation ensures M t serves as a cumulative visual record, where unexplored regions are explicitly represented as zerovalued frontiers (see Appendix for more gnomonic projection details).

Spatial-Aware Visual Prompting. To enable spatial reasoning, we augment M t with explicit geometric cues that transform the canvas into a structured navigation map. Specifically, we incorporate three types of visual prompts : (1) a central crosshair that highlights the current FoV center to facilitate egocentric-to-allocentric alignment; (2) a latitude-longitude grid at 30 ◦ intervals, which serves as a global scale for precise angular estimation; and (3) the exploration trajectory { ( θ 1 , ϕ 1 ) , . . . , ( θ t -1 , ϕ t -1 ) } , rendered as directed paths to track visited regions and prevent redundant scanning. By integrating the recorded memory M t with the current view V t , the agent effectively converts the search problem into a visual 'fill-in-the-blank' task on the 360 ◦ canvas.

## 4.2 PanoSeeker

The PanoSeeker serves as the spatial reasoning core, leveraging a Vision-Language Model (VLM) [10] to guide camera orientation control. This module processes a multi-modal input consisting of three key streams: (1) the current local observation V t ; (2) the annotated spatial memory map M t from EgoSphere; and (3) the instruction I . By jointly attending to the local view (for object detail) and the global map (for path planning), PanoSeeker addresses the search problem by predicting the next optimal action a t ∈ { (∆ θ t , ∆ ϕ t ) , [STOP] } .

Supervised Fine-Tuning (SFT) Stage. To empower the VLM [10] with active perception ability, we fine-tune PanoSeeker using an expert-annotated trajectory dataset. This stage explicitly trains PanoSeeker to predict the optimal viewpoint adjustment based on the current context. The objective function is defined as:

<!-- formula-not-decoded -->

where each expert trajectory T = { ( V t , M t , a t , I ) } T t =1 is sampled from the expert dataset D expert (detailed in section 3.2). The loss minimizes the negative log-likelihood of the expert action a t given the learned parameters θ of PanoSeeker, thereby learning the policy for efficient, non-redundant search.

Reinforcement Learning (RL) Stage. To enhance search efficiency, we fine-tune PanoSeeker using Group Relative Policy Optimization (GRPO) [35], which optimizes the policy through relative rewards within sampled groups without a separate critic. To formulate this reinforcement learning process, we first define the reward mechanism to guide the agent's behavior. For a navigation trajectory comprising states s t = ( V t , M t , I ) of length T , the overall cumulative reward is defined as r = ∑ T -1 t =1 R eff + R term . Specifically, the efficiency reward R eff = γ [ dist ( V t -1 , V ∗ ) -dist ( V t , V ∗ )] -η is computed at each step to encourage the agent to follow the shortest geodesic path while penalizing redundant exploration. Upon generating the [STOP] token at step T , the terminal reward R term assigns a success bonus R base + α · IoU if the agent successfully finds the target (dist ( V T , V ∗ ) &lt; τ ), and imposes a penalty -R pen otherwise. Given the cumulative reward r evaluated for each trajectory in a sampled group, we maximize the following GRPO objective:

<!-- formula-not-decoded -->

where p ref is the SFT reference model, G is the group size, and ϵ is the clipping parameter. The advantage A i for each action a t,i is computed by normalizing its reward r i within the group: A i = ( r i -mean ( { r g } )) / std ( { r g } ) . β weights the KL-divergence D KL for regularization.

## 4.3 Active Alignment and Segmentation

Upon receiving the [STOP] signal, PanoSeeker predicts a bounding box B by leveraging its inherent VLM [10] grounding ability. To address the challenges of boundary truncation and occlusion-which can lead to unstable mIoU metric evaluation-we implement an active alignment phase. Taking B as a prompt, we augment SAM-3 [67] to perform concurrent center-seeking, tracking, and segmentation. By applying a final angular adjustment (∆ θ ∗ , ∆ ϕ ∗ ) , the target's centroid is realigned to the optical center. This ensures the generation of a stable and accurate segmentation mask S for reliable performance evaluation.

## 5 Experiments

## 5.1 Implementation Details

Datasets and Environment. The APRS dataset comprises 7,420 samples across 4,971 scenes, partitioned 7:3 for training and testing. To provide a comprehensive evaluation, we adopt four primary metrics: (1) Success Rate (SR) to measure target localization accuracy; (2) Average Steps (AS) to assess search efficiency; (3) Success weighted by Path Length (SPL) to evaluate trajectory optimality; and (4) mean Intersection over Union (mIoU) to quantify segmentation quality. Each episode is limited to a maximum of T = 20 search steps. Each visual observation is rendered with a horizontal Field-of-View ( ψ h ) of 120 ◦ and a vertical Field-of-View ( ψ v ) of 90 ◦ , at a resolution of 1024 × 768 pixels.

Network Architecture: We employ Qwen3-VL-8B-Instruct [10] as the backbone for our PanoSeeker, benefiting from its superior reasoning and grounding ability for the APRS task. Specifically, the model is fine-tuned using a LoRA [68] adapter with a rank r = 64 , a scaling factor α = 64 , and a dropout rate of 0 . 05 . Furthermore, the EgoSphere memory is maintained at a resolution of 1024 × 512 , while SAM-3 [67] is used for final segmentation tasks.

Training Details: We implement our model using the DeepSpeed ZeRO-2 framework [69] and conduct training on 4 × NVIDIA RTX A6000 GPUs (48GB) with FP16 precision. For Supervised Fine-Tuning (SFT), we employ the AdamW [70] optimizer with a learning rate of 2 × 10 -4 and a weight decay of 0 . 1 . A cosine annealing scheduler is applied with a 3% warmup over 3 epochs. The training is performed with a per-GPU batch size of 1 and a gradient accumulation step of 4 , resulting in an effective batch size of 16 , with a sequence length limit of 4 , 096 tokens. In the Reinforcement Learning stage, we leverage the GRPO [35] ( G = 8 , ϵ = 0 . 2 ) for 6 , 000 steps to explicitly optimize exploration efficiency.

## 5.2 APRSBenchmarkResults

In Table 2, we report the quantitative results on our APRS benchmark, comparing PanoSeeker with previous state-of-the-art methods under three search paradigms: (1) Static Methods , which directly process the 360 ◦ equirectangular panorama (ERP) for referring image segmentation (RIS) in a single forward pass; (2) Heuristic Methods , which follow a predefined scanning paradigm traversing the upper, middle (equatorial), and lower spheres in order, ensuring complete 360 ◦ coverage of the space, where the search terminates once the model predicts a segmentation mask; and (3) VLM-based Agents , which serve as active controllers using task-specific prompts and textual log memory.

Table 2 Quantitative comparison on the APRS benchmark. We compare PanoSeeker with static RIS (processing the entire panorama), heuristic scanning (Upper → Equator → Lower), and active VLM agents. PanoSeeker achieves a significant leap in exploration efficiency (SPL and AS) thanks to its EgoSphere spatial memory and GRPO-optimized [35] policy. The best results are in bold .

| Method                                                   | Venue                                                    | Memory                                                   | SR(%) ↑                                                  | AS ↓                                                     | SPL ↑                                                    | mIoU(%) ↑                                                |
|----------------------------------------------------------|----------------------------------------------------------|----------------------------------------------------------|----------------------------------------------------------|----------------------------------------------------------|----------------------------------------------------------|----------------------------------------------------------|
| a. Static Methods (Direct Panorama Input)                | a. Static Methods (Direct Panorama Input)                | a. Static Methods (Direct Panorama Input)                | a. Static Methods (Direct Panorama Input)                | a. Static Methods (Direct Panorama Input)                | a. Static Methods (Direct Panorama Input)                | a. Static Methods (Direct Panorama Input)                |
| VLT [3]                                                  | [ICCV'21]                                                | ✗                                                        | 46.7                                                     | 1.0 ∗                                                    | -                                                        | 34.7                                                     |
| CRIS [36]                                                | [CVPR'22]                                                | ✗                                                        | 55.4                                                     | 1.0 ∗                                                    | -                                                        | 39.2                                                     |
| LISA [12]                                                | [CVPR'24]                                                | ✗                                                        | 64.1                                                     | 1.0 ∗                                                    | -                                                        | 44.5                                                     |
| SAM4MLLM [71]                                            | [ECCV'24]                                                | ✗                                                        | 62.3                                                     | 1.0 ∗                                                    | -                                                        | 46.2                                                     |
| VisionReasoner [15]                                      | [ICLR'26]                                                | ✗                                                        | 66.2                                                     | 1.0 ∗                                                    | -                                                        | 47.7                                                     |
| b. Heuristic Methods (Pre-defined Scanning, Max9steps) † | b. Heuristic Methods (Pre-defined Scanning, Max9steps) † | b. Heuristic Methods (Pre-defined Scanning, Max9steps) † | b. Heuristic Methods (Pre-defined Scanning, Max9steps) † | b. Heuristic Methods (Pre-defined Scanning, Max9steps) † | b. Heuristic Methods (Pre-defined Scanning, Max9steps) † | b. Heuristic Methods (Pre-defined Scanning, Max9steps) † |
| VLT [3]                                                  | [ICCV'21]                                                | ✗                                                        | 28.4                                                     | 4.6                                                      | 0.14                                                     | 22.1                                                     |
| CRIS [36]                                                | [CVPR'22]                                                | ✗                                                        | 32.1                                                     | 4.4                                                      | 0.17                                                     | 26.4                                                     |
| LISA [12]                                                | [CVPR'24]                                                | ✗                                                        | 42.3                                                     | 5.2                                                      | 0.22                                                     | 34.1                                                     |
| SAM4MLLM [71]                                            | [ECCV'24]                                                | ✗                                                        | 40.5                                                     | 5.3                                                      | 0.20                                                     | 32.5                                                     |
| VisionReasoner [15]                                      | [ICLR'26]                                                | ✗                                                        | 49.5                                                     | 4.9                                                      | 0.26                                                     | 39.9                                                     |
| c. VLM-based Agents (Active Exploration)                 | c. VLM-based Agents (Active Exploration)                 | c. VLM-based Agents (Active Exploration)                 | c. VLM-based Agents (Active Exploration)                 | c. VLM-based Agents (Active Exploration)                 | c. VLM-based Agents (Active Exploration)                 | c. VLM-based Agents (Active Exploration)                 |
| Qwen3-VL-30B-A3B-Thinking [10]                           | [ArXiv'25]                                               | Text Log                                                 | 62.9                                                     | 8.0                                                      | 0.29                                                     | 51.0                                                     |
| Gemini-3-Flash [72]                                      | -                                                        | Text Log                                                 | 64.9                                                     | 6.8                                                      | 0.31                                                     | 51.4                                                     |
| GPT-5.2 [66]                                             | -                                                        | Text Log                                                 | 69.1                                                     | 6.2                                                      | 0.36                                                     | 53.2                                                     |
| PanoSeeker (Ours)                                        | -                                                        | EgoSphere                                                | 75.4                                                     | 4.8                                                      | 0.57                                                     | 55.8                                                     |

Quantitative Comparison. As shown in Table 2, PanoSeeker achieves the best results across all metrics. Static methods struggle with panoramic image distortion and fail to recognize spatial referring expressions that are hard to identify in a single flat panorama. While heuristic scanning ensures coverage, its fixed path lacks reasoning, leading to many extra steps and a low 0.26 SPL. In contrast, active agents are more suitable for this task because they can reason during exploration. PanoSeeker achieves 75.4% SR and 55.8% mIoU, improving SPL by ∼ 58% over GPT-5.2 (0.57 vs. 0.36) with only 4.8 steps. These gains are attributed to our EgoSphere's explicit spatial visual memory for path planning and the GRPO-optimized [35] policy that enhances exploration efficiency.

Visualization. Fig. 3 shows PanoSeeker's search trajectories and how the EgoSphere is built step-by-step. Starting from the initial viewpoints (red dots), the agent iteratively adjusts its viewing direction ( ∆ θ, ∆ ϕ ) to explore the 360 ◦ environment for seeking and segmenting targets specified by language instructions. The EgoSphere progressively maps sequential local observations into a 360 ◦ map, helping the agent perceive the whole scene and improve exploration efficiency. These cases are only selected from episodes with the trajectory length of 4; more complex scenarios with longer trajectories are provided in the Appendix.

## 5.3 Ablation Study

We conduct ablation experiments to verify the effectiveness of all components. All variants use Qwen3-VL8B [10] as the backbone. All results are processed by the Active Alignment and Segmentation module to ensure stable evaluation.

ComponentEffectiveness. Table 3 shows the contribution of each component to the full PanoSeeker framework.

Figure 3 Visualization Results. Red dots denote initial viewpoints; blue boxes highlight final targets found by PanoSeeker. While these visualizations only show 4-step trajectories, extended scenarios can be found in the Appendix.

<!-- image -->

The zero-shot baseline (a) fails to navigate the 360 ◦ environment effectively, resulting in a high average step (AS=12.4) and low SPL (0.14) due to frequent 'dead loops.' Integrating EgoSphere (b) significantly improves efficiency, boosting the SPL to 0.26 by providing a persistent visual record that prevents redundant exploration. While the SFT stage (c) further improves the SR to 70.3% by learning experts' search trajectories, the addition of GRPO-based RL (d) achieves the best performance. Specifically, the RL strategy optimizes search trajectories for efficiency, reducing the average steps to 4.8 and reaching the highest SPL of 0.57. This demonstrates that while memory provides the necessary spatial context and historical trajectory, reinforcement learning is key to achieving optimal, non-redundant search paths.

Analysis of Memory Architectures. Table 4 compares various memory strategies in a zero-shot setting. We observe that textual logs (b), visual buffers (c), and hybrid approaches (d) lack sufficient spatial reasoning abilities. Even when past observations are recorded, these sequence-based methods struggle to maintain global context; notably, the hybrid buffer (d) even shows decreased performance due to multimodal information conflicts in the input (43.6 vs. 46.8 SR). In contrast, EgoSphere (e) uses geometric projection to unify local views into a continuous 360 ◦ representation, significantly outperforming the next-best variant (Textual Log) by 6.2% in SR and 0.05 in SPL. This highlights that for the APRS task, a geometrically consistent map is far more effective for spatial awareness than simply accumulating temporal logs or isolated observation frames.

## 6 Conclusion

In this paper, we introduce Active Panoramic Referring Segmentation (APRS), a novel task that requires an agent to actively explore 360 ◦ environments for target search and segmentation based on instructions. To address this, we propose PanoSeeker, a memory-augmented agent equipped with EgoSphere-an explicit spatial-visual memory that integrates sequential observations into a unified panoramic representation. By combining Supervised Fine-Tuning with Reinforcement Learning, we explicitly optimize the agent's active perception and spatial reasoning ability. Extensive experiments show that PanoSeeker outperforms existing adapted state-of-the-art baselines, establishing APRS as a scalable, cost-effective benchmark for advancing active perception in Embodied AI.

Table 3 Ablation of PanoSeeker components . (a) is a zero-shot baseline using task-specific prompts. We incrementally build upon it to reach our full framework (d).

| Variant                  | Training   | EgoSphere   | GRPO[35]   |   SR(%) ↑ |   AS ↓ |   SPL ↑ |   mIoU(%) ↑ |
|--------------------------|------------|-------------|------------|-----------|--------|---------|-------------|
| (a) Zero-shot            | None       | ✗           | ✗          |      41.6 |   12.4 |    0.14 |        28.5 |
| (b) + Memory             | None       | ✓           | ✗          |      56.5 |    8.7 |    0.26 |        39.9 |
| (c) + SFT                | SFT        | ✓           | ✗          |      70.3 |    6.2 |    0.40 |        50.7 |
| (d) + RL Strategy (Full) | SFT+RL     | ✓           | ✓          |      75.4 |    4.8 |    0.57 |        55.8 |

Table 4 Comparison of different memoryarchitectures in a zero-shot setting. All models are prompted to perform active searching. 'Visual Hist.' denotes the format of stored historical visual observations. 'ERP' denotes Equirectangular Panorama format.

| MemoryVariant            | Text Log   | Visual Hist.   |   SR(%) ↑ |   AS ↓ |   SPL ↑ |   mIoU(%) ↑ |
|--------------------------|------------|----------------|-----------|--------|---------|-------------|
| (a) Baseline (Zero-shot) | ✗          | ✗              |      41.6 |   12.4 |    0.14 |        28.5 |
| (b) + Textual Log        | ✓          | ✗              |      50.3 |    9.9 |    0.21 |        35.7 |
| (c) + Visual Buffer      | ✗          | 5 frames       |      46.8 |   10.5 |    0.17 |        32.0 |
| (d) + Hybrid Buffer      | ✓          | 5 frames       |      43.6 |   11.0 |    0.15 |        30.6 |
| (e) + EgoSphere (Ours)   | ✗          | 1 ERPcanvas    |      56.5 |    8.7 |    0.26 |        39.9 |

## References

- [1] Henghui Ding, Song Tang, Shuting He, Chang Liu, Zuxuan Wu, and Yu-Gang Jiang. Multimodal referring segmentation: A survey. IJCV , 2026.
- [2] Song Tang, Guangquan Jie, Henghui Ding, and Yu-Gang Jiang. ROSE: retrieval-oriented segmentation enhancement. In CVPR Findings , 2026.
- [3] Henghui Ding, Chang Liu, Suchen Wang, and Xudong Jiang. Vision-language transformer and query generation for referring segmentation. In ICCV , 2021.
- [4] Chang Liu, Henghui Ding, and Xudong Jiang. GRES: Generalized referring expression segmentation. In CVPR , 2023.
- [5] Henghui Ding, Chang Liu, Shuting He, Xudong Jiang, and Yu-Gang Jiang. GREx: Generalized referring expression segmentation, comprehension, and generation. IJCV , 134(2), 2026.
- [6] Henghui Ding, Chang Liu, Suchen Wang, and Xudong Jiang. VLT: vision-language transformer and query generation for referring segmentation. IEEE TPAMI , 45(6), 2022.
- [7] Henghui Ding, Chang Liu, Shuting He, Xudong Jiang, and Chen Change Loy. MeViS: A large-scale benchmark for video segmentation with motion expressions. In ICCV , 2023.
- [8] Haotian Liu, Chunyuan Li, Qingyang Wu, and Yong Jae Lee. Visual instruction tuning. NeurIPS , 36, 2023.
- [9] Peng Wang, Shuai Bai, Sinan Tan, Shijie Wang, Zhihao Fan, Jinze Bai, Keqin Chen, Xuejing Liu, Jialin Wang, Wenbin Ge, et al. Qwen2-vl: Enhancing vision-language model's perception of the world at any resolution. arXiv preprint arXiv:2409.12191 , 2024.
- [10] Shuai Bai, Yuxuan Cai, Ruizhe Chen, Keqin Chen, Xionghui Chen, Zesen Cheng, Lianghao Deng, Wei Ding, Chang Gao, Chunjiang Ge, et al. Qwen3-vl technical report. arXiv preprint arXiv:2511.21631 , 2025.

- [11] Xincheng Shuai, Song Tang, Yutong Huang, Henghui Ding, and Dacheng Tao. Psdesigner: Automated graphic design with a human-like creative workflow. In CVPR , 2026.
- [12] Xin Lai, Zhuotao Tian, Yukang Chen, Yanwei Li, Yuhui Yuan, Shu Liu, and Jiaya Jia. Lisa: Reasoning segmentation via large language model. In CVPR , 2024.
- [13] Zhuofan Xia, Dongchen Han, Yizeng Han, Xuran Pan, Shiji Song, and Gao Huang. Gsva: Generalized segmentation via multimodal large language models. In CVPR , 2024.
- [14] Rui Qian, Xin Yin, and Dejing Dou. Reasoning to attend: Try to understand how&lt; seg&gt; token works. In CVPR , 2025.
- [15] Yuqi Liu, Tianyuan Qu, Zhisheng Zhong, Bohao Peng, Shu Liu, Bei Yu, and Jiaya Jia. Visionreasoner: Unified visual perception and reasoning via reinforcement learning. arXiv e-prints , 2025.
- [16] Song Wang, Gongfan Fang, Lingdong Kong, Xiangtai Li, Jianyun Xu, Sheng Yang, Qiang Li, Jianke Zhu, and Xinchao Wang. Pixelthink: Towards efficient chain-of-pixel reasoning. arXiv preprint arXiv:2505.23727 , 2025.
- [17] Henghui Ding, Chang Liu, Shuting He, Kaining Ying, Xudong Jiang, Chen Change Loy, and Yu-Gang Jiang. MeViS: a multi-modal dataset for referring motion expression video segmentation. IEEE Transactions on Pattern Analysis and Machine Intelligence , 2025.
- [18] Kaining Ying, Henghui Ding, Guangquan Jie, and Yu-Gang Jiang. Towards Omnimodal Expressions and Reasoning in Referring Audio-Visual Segmentation. In ICCV , 2025.
- [19] Hengrui Hu, Weiwei Gao, Zipei Zhang, and Henghui Ding. RVAS: Referring video active exploration and segmentation. In ICML , 2026.
- [20] Wansen Wu, Tao Chang, Xinmeng Li, Quanjun Yin, and Yue Hu. Vision-language navigation: a survey and taxonomy. Neural Computing and Applications , 36(7), 2024.
- [21] Yuankai Qi, Qi Wu, Peter Anderson, Xin Wang, William Yang Wang, Chunhua Shen, and Anton van den Hengel. Reverie: Remote embodied visual referring expression in real indoor environments. In CVPR , 2020.
- [22] Shuting He, Henghui Ding, Xudong Jiang, and Bihan Wen. Segpoint: Segment any point cloud via large language model. In ECCV . Springer, 2024.
- [23] Qi Chen, Changli Wu, Jiayi Ji, Yiwei Ma, Danni Yang, and Xiaoshuai Sun. Ipdn: Image-enhanced prompt decoding network for 3d referring expression segmentation. In AAAI , volume 39, 2025.
- [24] Shuting He and Henghui Ding. Refmask3d: Language-guided transformer for 3d referring segmentation. In ACM MM , 2024.
- [25] Zhenyuan Qin, Xincheng Shuai, and Henghui Ding. Scenedesigner: Controllable multi-object image generation with 9-dof pose manipulation. In NeurIPS , 2025.
- [26] Xincheng Shuai, Henghui Ding, Zhenyuan Qin, Hao Luo, Xingjun Ma, and Dacheng Tao. Free-form motion control: Controlling the 6d poses of camera and objects in video generation. In ICCV , 2025.
- [27] Xincheng Shuai, Zhenyuan Qin, Henghui Ding, and Dacheng Tao. Free-form scene editor: Enabling multi-round object manipulation like in a 3d engine. In AAAI , 2025.
- [28] Ziye Li, Hao Luo, Xincheng Shuai, and Henghui Ding. Anyi2v: Animating any conditional image with motion control. In ICCV , 2025.
- [29] Shuting He, Guangquan Jie, Changshuo Wang, Yun Zhou, Shuming Hu, Guanbin Li, and Henghui Ding. ReferSplat: Referring segmentation in 3d gaussian splatting. In ICML , 2025.
- [30] Zhenyang Liu, Yikai Wang, Sixiao Zheng, Tongying Pan, Longfei Liang, Yanwei Fu, and Xiangyang Xue. Reasongrounder: Lvlm-guided hierarchical feature splatting for open-vocabulary 3d visual grounding and reasoning. In CVPR , 2025.
- [31] Yanqi Bao, Tianyu Ding, Jing Huo, Yaoli Liu, Yuxin Li, Wenbin Li, Yang Gao, and Jiebo Luo. 3d gaussian splatting: Survey, technologies, challenges, and opportunities. IEEE TCSVT , 35(7), 2025.
- [32] Shilin Yan, Xiaohao Xu, Renrui Zhang, Lingyi Hong, Wenchao Chen, Wenqiang Zhang, and Wei Zhang. Panovos: Bridging non-panoramic and panoramic views with transformer for video segmentation. In ECCV . Springer, 2024.
- [33] Yikang Zhou, Tao Zhang, Dizhe Zhang, Shunping Ji, Xiangtai Li, and Lu Qi. Dense360: Dense understanding from omnidirectional panoramas. arXiv preprint arXiv:2506.14471 , 2025.

- [34] Shih-Han Chou, Wei-Lun Chao, Wei-Sheng Lai, Min Sun, and Ming-Hsuan Yang. Visual question answering on 360deg images. In WACV , 2020.
- [35] Zhihong Shao, Peiyi Wang, Qihao Zhu, Runxin Xu, Junxiao Song, Xiao Bi, Haowei Zhang, Mingchuan Zhang, YK Li, Yang Wu, et al. Deepseekmath: Pushing the limits of mathematical reasoning in open language models. arXiv preprint arXiv:2402.03300 , 2024.
- [36] Zhaoqing Wang, Yu Lu, Qiang Li, Xunqiang Tao, Yandong Guo, Mingming Gong, and Tongliang Liu. Cris: Clip-driven referring image segmentation. In CVPR , 2022.
- [37] Ronghang Hu, Marcus Rohrbach, and Trevor Darrell. Segmentation from natural language expressions. In ECCV . Springer, 2016.
- [38] Chenxi Liu, Zhe Lin, Xiaohui Shen, Jimei Yang, Xin Lu, and Alan Yuille. Recurrent multimodal interaction for referring image segmentation. In ICCV , 2017.
- [39] Ruiyu Li, Kaican Li, Yi-Chun Kuo, Michelle Shu, Xiaojuan Qi, Xiaoyong Shen, and Jiaya Jia. Referring image segmentation via recurrent refinement networks. In CVPR , 2018.
- [40] Chang Liu, Xudong Jiang, and Henghui Ding. Primitivenet: decomposing the global constraints for referring segmentation. Visual Intelligence , 2(1):16, 2024.
- [41] Aaron Grattafiori, Abhimanyu Dubey, Abhinav Jauhri, Abhinav Pandey, Abhishek Kadian, Ahmad Al-Dahle, Aiesha Letman, Akhil Mathur, Alan Schelten, Alex Vaughan, et al. The llama 3 herd of models. arXiv preprint arXiv:2407.21783 , 2024.
- [42] Haoyu Lu, Wen Liu, Bo Zhang, Bingxuan Wang, Kai Dong, Bo Liu, Jingxiang Sun, Tongzheng Ren, Zhuoshu Li, Hao Yang, et al. Deepseek-vl: towards real-world vision-language understanding. arXiv preprint arXiv:2403.05525 , 2024.
- [43] Aixin Liu, Bei Feng, Bing Xue, Bingxuan Wang, Bochao Wu, Chengda Lu, Chenggang Zhao, Chengqi Deng, Chenyu Zhang, Chong Ruan, et al. Deepseek-v3 technical report. arXiv preprint arXiv:2412.19437 , 2024.
- [44] Zhe Chen, Jiannan Wu, Wenhai Wang, Weijie Su, Guo Chen, Sen Xing, Muyan Zhong, Qinglong Zhang, Xizhou Zhu, Lewei Lu, et al. Internvl: Scaling up vision foundation models and aligning for generic visual-linguistic tasks. In CVPR , 2024.
- [45] Yuqi Liu, Bohao Peng, Zhisheng Zhong, Zihao Yue, Fanbin Lu, Bei Yu, and Jiaya Jia. Seg-zero: Reasoning-chain guided segmentation via cognitive reinforcement. arXiv preprint arXiv:2503.06520 , 2025.
- [46] Charles Packer, Vivian Fang, Shishir\_G Patil, Kevin Lin, Sarah Wooders, and Joseph\_E Gonzalez. Memgpt: towards llms as operating systems. 2023.
- [47] Jiazheng Kang, Mingming Ji, Zhe Zhao, and Ting Bai. Memory os of ai agent. In EMNLP , 2025.
- [48] Wanjun Zhong, Lianghong Guo, Qiqi Gao, He Ye, and Yanlin Wang. Memorybank: Enhancing large language models with long-term memory. In AAAI , volume 38, 2024.
- [49] Wujiang Xu, Zujie Liang, Kai Mei, Hang Gao, Juntao Tan, and Yongfeng Zhang. A-mem: Agentic memory for llm agents. arXiv preprint arXiv:2502.12110 , 2025.
- [50] Zhanghao Hu, Qinglin Zhu, Hanqi Yan, Yulan He, and Lin Gui. Beyond rag for agent memory: Retrieval by decoupling and aggregation. arXiv preprint arXiv:2602.02007 , 2026.
- [51] Xinlei Yu, Chengming Xu, Guibin Zhang, Zhangquan Chen, Yudong Zhang, Yongbo He, Peng-Tao Jiang, Jiangning Zhang, Xiaobin Hu, and Shuicheng Yan. Vismem: Latent vision memory unlocks potential of vision-language models. arXiv preprint arXiv:2511.11007 , 2025.
- [52] Volkan Cirik, Taylor Berg-Kirkpatrick, and Louis-Philippe Morency. Refer360 ◦ : A referring expression recognition dataset in 360 ◦ images. In ACL , 2020.
- [53] Hao Ai, Zidong Cao, and Lin Wang. A survey of representation learning, optimization strategies, and applications for omnidirectional vision: H. ai et al. IJCV , 133(8), 2025.
- [54] Atsuya Nakata and Takao Yamanaka. 2s-odis: Two-stage omni-directional image synthesis by geometric distortion correction. In ECCV . Springer, 2024.
- [55] Fanghua Yu, Xintao Wang, Mingdeng Cao, Gen Li, Ying Shan, and Chao Dong. Osrt: Omnidirectional image super-resolution with distortion-aware transformer. In CVPR , 2023.

- [56] Keisuke Tateno, Nassir Navab, and Federico Tombari. Distortion-aware convolutional filters for dense prediction in panoramic images. In ECCV , 2018.
- [57] Yu-Chuan Su and Kristen Grauman. Learning spherical convolution for fast features from 360 imagery. NeurIPS , 30, 2017.
- [58] Yu-Chuan Su and Kristen Grauman. Kernel transformer networks for compact spherical convolution. In CVPR , 2019.
- [59] Xincheng Shuai, Henghui Ding, Xingjun Ma, Rongcheng Tu, Yu-Gang Jiang, and Dacheng Tao. A survey of multimodal-guided image editing with text-to-image diffusion models. arXiv preprint arXiv:2406.14555 , 2024.
- [60] Zihao Dongfang, Xu Zheng, Ziqiao Weng, Yuanhuiyi Lyu, Danda Pani Paudel, Luc Van Gool, Kailun Yang, and Xuming Hu. Are multimodal large language models ready for omnidirectional spatial reasoning? arXiv preprint arXiv:2505.11907 , 2025.
- [61] Xincheng Shuai, Ziye Li, Henghui Ding, and Dacheng Tao. Glyphprinter: Region-grouped direct preference optimization for glyph-accurate visual text rendering. In CVPR , 2026.
- [62] Shih-Han Chou, Cheng Sun, Wen-Yen Chang, Wan-Ting Hsu, Min Sun, and Jianlong Fu. 360-indoor: Towards learning real-world objects in 360deg indoor equirectangular images. In WACV , 2020.
- [63] Hang Xu, Qiang Zhao, Yike Ma, Xiaodong Li, Peng Yuan, Bailan Feng, Chenggang Yan, and Feng Dai. Pandora: A panoramic detection dataset for object with orientation. In ECCV . Springer, 2022.
- [64] Jianxiong Xiao, Krista A Ehinger, Aude Oliva, and Antonio Torralba. Recognizing scene viewpoint using panoramic place representation. In CVPR . IEEE, 2012.
- [65] Dave Zhenyu Chen, Angel X Chang, and Matthias Nießner. Scanrefer: 3d object localization in rgb-d scans using natural language. In ECCV . Springer, 2020.
- [66] Aaditya Singh, Adam Fry, Adam Perelman, Adam Tart, Adi Ganesh, Ahmed El-Kishky, Aidan McLaughlin, Aiden Low, AJ Ostrow, Akhila Ananthram, et al. Openai gpt-5 system card. arXiv preprint arXiv:2601.03267 , 2026.
- [67] Nicolas Carion, Laura Gustafson, Yuan-Ting Hu, Shoubhik Debnath, Ronghang Hu, Didac Suris, Chaitanya Ryali, Kalyan Vasudev Alwala, Haitham Khedr, Andrew Huang, et al. Sam 3: Segment anything with concepts. arXiv preprint arXiv:2511.16719 , 2025.
- [68] Edward J Hu, Yelong Shen, Phillip Wallis, Zeyuan Allen-Zhu, Yuanzhi Li, Shean Wang, Lu Wang, and Weizhu Chen. LoRA: Low-rank adaptation of large language models. In ICLR , 2022.
- [69] Samyam Rajbhandari, Jeff Rasley, Olatunji Ruwase, and Yuxiong He. Zero: Memory optimizations toward training trillion parameter models. In SC20: international conference for high performance computing, networking, storage and analysis . IEEE, 2020.
- [70] Ilya Loshchilov and Frank Hutter. Decoupled weight decay regularization. arXiv preprint arXiv:1711.05101 , 2017.
- [71] Yi-Chia Chen, Wei-Hua Li, Cheng Sun, Yu-Chiang Frank Wang, and Chu-Song Chen. Sam4mllm: Enhance multi-modal large language model for referring expression segmentation. In ECCV . Springer, 2024.
- [72] Gemini Team, Rohan Anil, Sebastian Borgeaud, Jean-Baptiste Alayrac, Jiahui Yu, Radu Soricut, Johan Schalkwyk, Andrew M Dai, Anja Hauth, Katie Millican, et al. Gemini: a family of highly capable multimodal models. arXiv preprint arXiv:2312.11805 , 2023.